/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Model.Blog;
import Model.Manager;
import Model.Manager2;
import Model.Message;
import Model.Register;
import java.util.ArrayList;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;


public class Prueba {
    public static void main(String[] args) throws ParserConfigurationException, SAXException {
          Message mensaje = new Message();
         Register registro = new Register();
         ArrayList<Register> registros = new ArrayList<>();
         Blog bitacora = new Blog(registros);
         Manager man1 = new Manager(mensaje, registro, bitacora);
        Manager2 man = new Manager2(man1);
        
        man.Iniciar();
        man.Menu();
         
         
          
         
    }
}