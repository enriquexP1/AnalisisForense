/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Manager {
public static SimpleDateFormat sdfResult = new SimpleDateFormat("HH:mm:ss", Locale.US);
public static SimpleDateFormat sdfResultSegundos = new SimpleDateFormat("s", Locale.US);
public static SimpleDateFormat sdfResultMinutos =  new SimpleDateFormat("m", Locale.US);
    
    private Blog bitacora;
    private ArrayList<Register> registros ;
    HashMap<String, String> tablaPaises ;
    HashMap<String, String > tablaConteoIp;
    HashMap<String,String> tablaConteoUser;
    HashMap<String , ArrayList<Register>> tablaConsultaUsuarios;
    public Manager(Message mensaje, Register registro, Blog bitacora) {
        
        this.bitacora = bitacora;
        tablaPaises= new HashMap<String,String>();
        tablaConteoIp= new HashMap<String, String >();
        tablaConteoUser= new HashMap<String, String >();
        tablaConsultaUsuarios= new HashMap<String , ArrayList<Register>>();
    }

    public Manager() {
    }
    
    
        public static String SetPais(String ip) throws IOException, ParserConfigurationException, SAXException
    {
        
           // System.out.println(listaPaises.get(i));
       String nombrePais;
        
       
       
           
         
          if(ip.compareTo("162.204.50.89") != 0  )
          {
              URL url= new URL("http://api.geoiplookup.net/?query="+ip);
        
             URLConnection urlConnection = url.openConnection();
             urlConnection.addRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)");
             InputStream input = new BufferedInputStream(urlConnection.getInputStream());    
             DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
             Document doc = dBuilder.parse(input);
             NodeList nombreCountry=doc.getElementsByTagName("countryname").item(0).getChildNodes();
             nombrePais =nombreCountry.item(0).getTextContent();
          }
          else
          {
              nombrePais= "Sin pais" ;
              
          }
            
            
            
            
            
       return nombrePais;

    }
  
        public ArrayList TomarBitacora() throws ParserConfigurationException, SAXException
    {
        
        
       
        int pos = 0;
        String linea = "";
        registros = new ArrayList<Register>();
        FileReader fr;
        try {
            fr = new FileReader("auth.log");
            BufferedReader br = new BufferedReader(fr);
            linea= br.readLine();
          
            while(linea  != null )
            {
              
              pos++;
             Message mensaje = new Message();
             Register registro = new  Register();
              User usuario = new User();
              Server servidor = new Server();
             
              //si contiene este diferenciador avanzamos
             
              
              
        
              Pattern diferenciador = Pattern.compile("Failed password");
              Pattern rut = Pattern.compile("root");
              Pattern ip   =  Pattern.compile("((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)");
              Matcher ipMat = ip.matcher(linea);
              Matcher rutMat= rut.matcher(linea);
             
             
              Matcher diferenciadorMat = diferenciador.matcher(linea);
             
              //si contiene la palabra failPassword se filtra 
              //es una linea de este estilo Failed password for invalid user MikroTik from 14.249.51.146 port 56147 ssh2
                   
              if(diferenciadorMat.find())
                 {
                     
                     if(rutMat.find())
                     {
                     StringTokenizer tokens =  new StringTokenizer(linea, " ");
                      String mes = tokens.nextToken();
                      String dia = tokens.nextToken();
                      String hora = tokens.nextToken();
                      String nombre = tokens.nextToken();
                      String usuar="root";
                      usuario.setNombre(usuar);
                      ipMat.find();
                     
                              
                      
                      String ipe= ipMat.group();
                      Country pais = new Country();
                      mensaje.setUser(usuario);
                      mensaje.setIp(ipe);
                      mensaje.setSeverity("ssh2");
                     
                      setHash(ipe, pais);
                         ContarUsuarios(usuario);
                      mensaje.setPais(pais);
                      registro.setFecha(mes+dia);
                      registro.setMensaje(mensaje);
                      servidor.setNombre(nombre);
                      registro.setServidor(servidor);
                      RecopilarUsuaios(usuario, registro);
                      //System.out.println(mes + " " + dia +" " + hora + " " + nombre + " " + ipe + " " + pais.getNombre() +" " + usuario.getNombre() );
                      
                     
                     }
                     else
                     {
                      StringTokenizer tokens =  new StringTokenizer(linea, " ");
                      String mes = tokens.nextToken();
                      String dia = tokens.nextToken();
                      String hora = tokens.nextToken();
                      String nombre = tokens.nextToken();
                      ipMat.find();
                      String[] parts = linea.split(" ");              
                      String usuar= parts[10];
                      usuario.setNombre(usuar);
                       String ipe= ipMat.group();
                      Country pais = new Country();
                      setHash(ipe, pais);
                         ContarUsuarios(usuario);
                      
                      mensaje.setIp(ipe);
                      mensaje.setSeverity("ssh2");
                      mensaje.setPais(pais);
                      
                      mensaje.setUser(usuario);
                      registro.setFecha(mes+dia);
                      registro.setHora(hora);
                      registro.setMensaje(mensaje);
                      servidor.setNombre(nombre);
                      registro.setServidor(servidor);
                      registros.add(registro);
                      RecopilarUsuaios(usuario, registro);
                     // System.out.println(mes + " " + dia +" " + hora + " " + nombre + " " + ipe + " " + pais.getNombre()+" " + usuario.getNombre() );
                      
                     
                     }
 
                 }

               linea=br.readLine();
  
            }
             br.close();//ojo aquí cuate si yo no le pongo esto, y alquien sale del programa y quiere hacer otra consulta 
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Manager.class.getName()).log(Level.SEVERE, null, ex);
        }

        return registros;

    }
        
     public Country setHash( String ip,Country pais) throws IOException, ParserConfigurationException, SAXException
     {//si la ip esta dentro del mapa entonces 
         
         if(tablaPaises.containsKey(ip) )
         {
             pais.setNombre(tablaPaises.get(ip));
            int contador= Integer.parseInt(tablaConteoIp.get(ip));
            contador=contador+1;
            String cont = ""+contador;
            tablaConteoIp.put(ip, cont);
            
             
             
             
         }
         else
         {
             String paisnombre = SetPais(ip);
             pais.setNombre(paisnombre);
             
             tablaPaises.put(ip,pais.getNombre());
             tablaConteoIp.put(ip, "1");
             
             
             
         }    
      
      return pais;
     
     }
    
    public void ContarUsuarios(User usuario)
    {
      if(tablaConteoUser.containsKey(usuario.getNombre()))
      {
        String cont=tablaConteoUser.get(usuario.getNombre());
        int contador = Integer.parseInt(cont);
        contador= contador+1;
        cont = ""+contador;
        tablaConteoUser.put(usuario.getNombre(), cont);
        
      
      }
      else
      {
        tablaConteoUser.put(usuario.getNombre(), "1");
      }
    
    }
    
    public void RecopilarUsuaios(User usuario,Register registro)
    {
     if(tablaConsultaUsuarios.containsKey(usuario.getNombre()))
     {
         ArrayList<Register> array;
         array= tablaConsultaUsuarios.get(usuario.getNombre());
         array.add(registro);
     }
     else
     {
         ArrayList<Register> array = new ArrayList<>();
         array.add(registro);
         tablaConsultaUsuarios.put(usuario.getNombre(), array);
         
         
     }
    
    }
    public void imprimirUsuariosRecopilados()
    {
     tablaConsultaUsuarios.entrySet().forEach(entry -> {
            ArrayList<Register> lista;
            lista= entry.getValue();
            
            System.out.println(entry.getKey());
            for(int i=0 ; i<lista.size() ;i++)
            {
                System.out.println(lista.get(i).toString());
            }
        });
    
    }
    public void imprimirRegistrosUsuario(String usuario)
    {
       if(tablaConsultaUsuarios.containsKey(usuario))
       {
         ArrayList<Register>lista;
         lista= tablaConsultaUsuarios.get(usuario);
           System.out.println("Usuario: "  + usuario);
         for(int i=0 ; i<lista.size() ;i++)
            {
                System.out.println(lista.get(i).toString());
            }
       
       }
       else
       {
                 System.out.println("No se encontró el usuario");
       
       }
    
    }
    public void imprimirUsuarios()
    {
        
        tablaConteoUser.entrySet().forEach(entry -> {
            System.out.println(entry.getKey()+" = "+entry.getValue());
        });
        
    
    }
    public void imprimirIps()
    {
        tablaConteoIp.entrySet().forEach(entry -> {
            System.out.println(entry.getKey()+" = "+entry.getValue());
        });
    }
    public void BuscarConteoIp(String ip)
    {
      if(tablaConteoIp.containsKey(ip))
      {
          System.out.println("la IP:"+ip+" se ah encontrado:" +tablaConteoIp.get(ip) +"veces" );
      }
      else
      {
          System.out.println("No se encuetra ");
      }
    }
    public void BuscarConteoUsuarios(String Usuario)
    {
      if(tablaConteoUser.containsKey(Usuario))
      {
          System.out.println("el usuario"+Usuario+" ah incurrido:" +tablaConteoUser.get(Usuario) +"veces" );
      }
      else
      {
          System.out.println(" Usuario no encontrado");
      }
    }
    
    public Date diferenciarHoras(Date InicioHora, Date finalHora)
{
    
    long millisegundos = finalHora.getTime() - InicioHora.getTime();
    int segundos = (int) (millisegundos / 1000) % 60;
    int minutos = (int) ((millisegundos / (1000 * 60)) % 60);
    int horas = (int) ((millisegundos / (1000 * 60 * 60)) % 24);
     Calendar c = Calendar.getInstance();
    c.set(Calendar.SECOND, segundos);
    c.set(Calendar.MINUTE, minutos);
    c.set(Calendar.HOUR_OF_DAY, horas);
    int diferencia = Integer.parseInt(sdfResultMinutos.format(finalHora));
   
    
    return c.getTime();
    


}
    public void ReconstruirAtaque(String usuario) throws ParseException
    {
        //si la lista contiene menos de 3 ataques es muy probable que no sea un ataque como tal
      int determiante=0;
      if(tablaConsultaUsuarios.containsKey(usuario))
       {
         ArrayList<Register>lista;
         lista= tablaConsultaUsuarios.get(usuario);
           System.out.println("Usuario: "  + usuario);
           if(lista.size()<3)
           {
               System.out.println("Ataque humano o error en contraseña");
           
           }
           //si tiene mas de 3 ataques tenemos que realizar una comprobacion de 3 intentos
           else
           {
           
            
                for(int j=0 ; j< 5 ; j++)
                {
                 String horaInicio =lista.get(j).getHora();
                 String horaFinal = lista.get(j+1).getHora();
                 Date difference = diferenciarHoras(sdfResult.parse(horaInicio),sdfResult.parse(horaFinal));
                 int diferenciaMinutos =  Integer.parseInt(sdfResultMinutos.format(difference));
                 int diferenciaSegundos = Integer.parseInt(sdfResultSegundos.format(difference));
                 if(diferenciaMinutos <= 1 && diferenciaSegundos< 40)
                 {
                   determiante= determiante +1;                   
                 }
                 
                }
                
                
              
           }
           
           if(determiante > 2 || determiante >= 3 )
           {
               System.out.println("Ataque por Maquina");
           }
           else
           {
              System.out.println("Ataque humano o error en contraseña");
           }
           BuscarConteoUsuarios(usuario);
           imprimirRegistrosUsuario(usuario);
       }
       else
       {
                 System.out.println("No se encontró el usuario");
       
       }
    
    }
}
