/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

//Clase encargada de leer el contenido de la bitacora 
public class Message {
    private User user;
    private String ip;
    private String port;
    private String status;
    private String protocol;
    private String code;
    private Country pais;
  
   public Message()
   {
   
   }
    public Message(User user, String ip, String port, String status, String protocol, String code) {
        this.user = user;
        this.ip = ip;
        this.port = port;
        this.status = status;
        this.protocol = protocol;
        this.code = code;
    }
   
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSeverity() {
        return status;
    }

    public void setSeverity(String status) {
        this.status = status;
    }

 
    public Country getPais() {
        return pais;
    }

    public void setPais(Country pais) {
        this.pais = pais;
    }
    
    @Override
    public String toString()
    {
    return user.getNombre() +"  "+ ip+"  " + pais.getNombre();
    }
}
