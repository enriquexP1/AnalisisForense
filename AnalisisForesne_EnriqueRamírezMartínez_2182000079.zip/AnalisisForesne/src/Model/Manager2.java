/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;


public class Manager2{
   private  Manager man ;
    public Manager2(Manager man)
    {
       this.man= man;
    }
   public void Iniciar() throws ParserConfigurationException, SAXException
   {
       System.out.println("Por favor espere un momento");
   man.TomarBitacora();
       System.out.println("Lectura completada");
   
   }
    public void Menu () throws ParserConfigurationException, SAXException, ParseException
    {
        String retorno;
        Scanner Retu = new Scanner(System.in);
         System.out.println("Bienvenido\n");
         System.out.println("Selecciona una opcion\n");
         System.out.println("1.Buscar coincidencias IP\n");
         System.out.println("2.Buscar coincidencias Usuaios\n");
         System.out.println("3.Imprimir Usuarios con incidencias\n");
         System.out.println("4.Imprimir Ips con incidencias\n");
         System.out.println("5.Imprimir usuarios con Mesnajes recopilados\n");
         System.out.println("6.Buscar usuario con registros\n");
         System.out.println("7.Reconstruir ataque en base a usuario\n");
         Scanner entrada = new Scanner(System.in);
         int entradita = Integer.parseInt(entrada.nextLine());
         switch(entradita)
         {
             case 1:
                 System.out.println("Ingrese la Ip que desea buscar:");
                  Scanner ipScan = new Scanner(System.in);
                  String ip = ipScan.nextLine();
                  man.BuscarConteoIp(ip);
                  System.out.println("Deseas regresar, pulsa (y/n)");
                  retorno = Retu.nextLine();
                  if("y".equals(retorno))
                  {
                    Menu();
                  }
                 break;
            case 2:
                System.out.println("Ingrese el usuario que desea buscar:");
                  Scanner UserScan = new Scanner(System.in);
                  String usuario = UserScan.nextLine();
                  man.BuscarConteoUsuarios(usuario);
                  System.out.println("Deseas regresar, pulsa (y/n)");
                  retorno = Retu.nextLine();
                  if("y".equals(retorno))
                  {
                    Menu();
                  }
                 break;
            case 3:
                 man.imprimirUsuarios();
                 System.out.println("Deseas regresar, pulsa (y/n)");
                 retorno = Retu.nextLine();
                 
                  if("y".equals(retorno)|| "Y".equals(retorno))
                  {
                    Menu();
                  }
                break;
            case 4:
                man.imprimirIps();
                System.out.println("Deseas regresar, pulsa (y/n)");
                retorno = Retu.nextLine();
                  if("y".equals(retorno)|| "Y".equals(retorno))
                  {
                    Menu();
                  }
                break;
                case 5:
                man.imprimirUsuariosRecopilados();
                System.out.println("Deseas regresar, pulsa (y/n)");
                retorno = Retu.nextLine();
                  if("y".equals(retorno)|| "Y".equals(retorno))
                  {
                    Menu();
                  }
                break;
                case 6:
                  System.out.println("Ingrese el usuario que desea buscar:");
                  Scanner UserScan2 = new Scanner(System.in);
                  String usuarios = UserScan2.nextLine();
                  man.imprimirRegistrosUsuario(usuarios);
                  System.out.println("Deseas regresar, pulsa (y/n)");
                  retorno = Retu.nextLine();
                  if("y".equals(retorno))
                  {
                    Menu();
                  }
                  case 7:
                  System.out.println("Ingrese el usuario que desea buscar:");
                  Scanner UserScan3 = new Scanner(System.in);
                  String usuarioss = UserScan3.nextLine();
                  man.ReconstruirAtaque(usuarioss);
                  System.out.println("Deseas regresar, pulsa (y/n)");
                  retorno = Retu.nextLine();
                  if("y".equals(retorno))
                  {
                    Menu();
                  }
                    break;
         }
    
    }
}
