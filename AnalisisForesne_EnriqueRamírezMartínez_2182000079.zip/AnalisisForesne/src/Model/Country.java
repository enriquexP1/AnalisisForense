package Model;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class Country {
   private String nombre;
   private String codigo;
    

    public String getNombre() {
        return nombre;
    }
   public String getCodigo()
   {
       return codigo;
   
   }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Country{" + "nombre=" + nombre + ", codigo=" + codigo + '}';
    }
    
    
   
   
}