/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

//clase encargada de recopilar el contenido de los mensajes con su pais 
public class Register {
    private String fecha;
    private String hora;
    private Message mensaje;
    private String tipo;
    private Server servidor;
    public Register(String fecha, Message mensaje, String tipo) {
        this.fecha = fecha;
        this.mensaje = mensaje;
        this.tipo = tipo;
    }

    public Server getServidor() {
        return servidor;
    }

    public void setServidor(Server servidor) {
        this.servidor = servidor;
    }
   
    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Register() {
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Message getMensaje() {
        return mensaje;
    }

    public void setMensaje(Message mensaje) {
        this.mensaje = mensaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return  "fecha=  " + fecha +" " + hora +" usuario :" +  mensaje.getUser().getNombre() + " ip: " + mensaje.getIp() + " pais: " +mensaje.getPais().getNombre();
    }
    
    
}
