/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


public class Server {
 private Blog blog ; 
 private String sistemaOperativo;
 private String prioridad;
 private String nivelDeSeguridad;
 private String nombre;

    public Server()
    {
    }
    public Server(Blog blog, String sistemaOperativo, String prioridad, String nivelDeSeguridad) {
        this.blog = blog;
        this.sistemaOperativo = sistemaOperativo;
        this.prioridad = prioridad;
        this.nivelDeSeguridad = nivelDeSeguridad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Blog getBlog() {
        return blog;
    }

    public void setBlog(Blog blog) {
        this.blog = blog;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(String sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getNivelDeSeguridad() {
        return nivelDeSeguridad;
    }

    public void setNivelDeSeguridad(String nivelDeSeguridad) {
        this.nivelDeSeguridad = nivelDeSeguridad;
    }

    @Override
    public String toString() {
        return "Server{" + "blog=" + blog + ", sistemaOperativo=" + sistemaOperativo + ", prioridad=" + prioridad + ", nivelDeSeguridad=" + nivelDeSeguridad + '}';
    }
    
}
